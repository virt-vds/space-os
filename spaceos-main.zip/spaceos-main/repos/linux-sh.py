import os
import time
print("Linux sh starting...")
time.sleep(0.1)
os.system("sh")
