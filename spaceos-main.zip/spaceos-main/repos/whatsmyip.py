import requests
response = requests.get("https://ifconfig.me")
print(response)
